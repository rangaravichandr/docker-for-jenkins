package com.javatechie.docker.compose;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMongodbDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
